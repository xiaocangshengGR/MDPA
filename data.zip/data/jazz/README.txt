List of edges of the network of Jazz musicians. Data compiled by members of our group. 

data source��http://deim.urv.cat/~alexandre.arenas/data/welcome.htm