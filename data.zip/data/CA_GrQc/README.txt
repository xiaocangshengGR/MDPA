# Undirected graph : CA-GrQc.txt 
# Collaboration network of Arxiv General Relativity category (there is an edge if authors coauthored at least one paper)
# Nodes: 5242 Edges: 28980
# FromNodeId	ToNodeId

data source��http://snap.stanford.edu/data/ca-GrQc.html