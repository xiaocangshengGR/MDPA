Social network of friendships between 34 members of a karate club at a US university in the 1970s.



data source��http://www-personal.umich.edu/~mejn/netdata/