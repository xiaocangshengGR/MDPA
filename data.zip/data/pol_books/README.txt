A network of books about US politics published around the time of the 2004 presidential election and sold by the online bookseller Amazon.com. Edges between books represent frequent copurchasing of books by the same buyers. 



data source��http://www-personal.umich.edu/~mejn/netdata/