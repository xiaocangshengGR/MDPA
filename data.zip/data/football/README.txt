American College football: network of American football games between Division IA colleges during regular season Fall 2000. 

undirected
nodes:115
edges:613

data source��http://www-personal.umich.edu/~mejn/netdata/