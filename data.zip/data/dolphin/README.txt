An undirected social network of frequent associations between 62 dolphins in a community living off Doubtful Sound, New Zealand.


data source��http://www-personal.umich.edu/~mejn/netdata/